#pragma once
#include "TList.h"
#include <iostream>
using namespace std;

class TPolinom : public THeadList<TMonom>
{
	friend ostream& operator<< (ostream& os, TPolinom& p);
public:
	TPolinom(int monoms[][2] = NULL, int km = 0) {
		TMonom tmp(0, 1);
		pHead->val = tmp;
		for (int i = 0; i < km; i++) {
			TMonom monom((double)monoms[i][0], monoms[i][1]);
			InsLast(monom);
		}
	}

	TPolinom(TPolinom& TP) {
		TMonom m(0, -1);
		pHead->val = m;
		for (TP.Reset(); !TP.IsEnd(); TP.GoNext()) {
			TMonom monom = TP.GetCurr();
			InsLast(monom);
		}
	}

	TMonom GetMonom() {
		TMonom monom = GetCurr();
		return monom;
	}

	TPolinom& operator+ (TPolinom& pol)
	{
		TPolinom res(*this);
		res.Reset();
		pol.Reset();
		while (res.pCurr != res.pStop && pol.pCurr != pol.pStop)
		{
			if (res.GetCurr().Index < pol.GetCurr().Index)
			{
				res.InsCurr(pol.GetCurr());
				pol.GoNext();
			}
			else
				if (res.GetCurr().Index > pol.GetCurr().Index)
				{
					res.GoNext();
				}
				else
				{
					res.pCurr->val.Coeff = pol.pCurr->val.Coeff + res.pCurr->val.Coeff;
					if (res.pCurr->val.Coeff != 0)
					{
						pol.GoNext();
						res.GoNext();
					}
					else
					{
						res.DelCurr();
						pol.GoNext();
					}
				}

		}
		return res;
	}

	TPolinom& operator* (double c)
	{
		TPolinom res(*this);
		if (c == 0)
		{
			res.DelList();
		}
		else
		{

			res.Reset();
			while (!res.IsEnd())
			{
				res.pCurr->val.Coeff = res.pCurr->val.Coeff * c;
				res.GoNext();
			}
		}
		return res;
	}

	TPolinom& operator- (TPolinom& pol)
	{
		TPolinom res = (*this + pol * (-1));
		return res;
	}

	TPolinom& operator+= (TPolinom& q) {
		// P = x^2y^2z^2 + x^1y^1z^1 + ...... + 5
		// Q = x^3y^2z^2 + x^3y^1z^1 + ...... + 3
		// P + Q = 

		TMonom pm, qm, rm;
		this->Reset();
		while (1) {
			pm = GetMonom();
			qm = q.GetMonom();
			if (pm.Index < qm.Index) {
				//monom pm younger than monom qm => add monom qm into P
				InsCurr(qm);
				q.GoNext();
			}
			else if (pm.Index > qm.Index)
				GoNext();
			else {
				// indexes  are equal (but they could pHeads) 
				if (pm.Index == -1)
					break;
				pm.Coeff += qm.Coeff;
				if (pm.Coeff != 0)
				{
					GoNext();
					q.GoNext();
				}
				else {
					// deleting monom with 0-coeff
					DelCurr();
					q.GoNext();
				}
			}
		}
		return *this;
	}

	TPolinom& operator= (TPolinom& TP) {
		DelList();
		for (TP.Reset(); !TP.IsEnd(); TP.GoNext()) {
			TMonom monom = TP.GetCurr();
			InsLast(monom);
		}
		return *this;
	}

	void AddMonom(TMonom _m) {
		if (pCurr == nullptr)
		{
			InsFirst(_m);
		}
		pCurr = pFirst;
		while (_m.Index < pCurr->val.Index) {
			GoNext();
		}
		if (pCurr->val == _m) {
			if (_m.Coeff + pCurr->val.Coeff == 0)
				DelCurr();
			else
				pCurr->val.Coeff = _m.Coeff + pCurr->val.Coeff;
		}
		else
			InsCurr(_m);
	}

	void EnterPolinom()
	{
		int i; double c;
		cout << "������� ����������� � ������ ������������ ������.\n0 - ��������� ����.";
		cin >> c >> i;
		if (i < 100) throw ("wrong index");
		while (1)
		{
			TMonom newmonom(c, i);
			AddMonom(newmonom);
			cin >> c;
			if (c == 0) break;
			cin >> i;
			if (i == 0) break;
			if (i < 100) throw ("wrong index");

		}
	}


	friend ostream& operator<< (ostream& os, TPolinom& p)
	{
		p.Reset();
		int x, y, z;
		x = p.GetCurr().Index / 100;
		y = p.GetCurr().Index % 100 / 10;
		z = p.GetCurr().Index % 10;
		os << p.GetCurr().Coeff << "(x^" << x << "y^" << y << "z^" << z << ")";
		p.GoNext();
		while (!p.IsEnd())
		{
			x = p.GetCurr().Index / 100;
			y = p.GetCurr().Index % 100 / 10;
			z = p.GetCurr().Index % 10;
			if (p.GetCurr().Coeff > 0)
				os << "+";

			os << p.GetCurr().Coeff << "(x^" << x << "y^" << y << "z^" << z << ")";
			p.GoNext();
		}
		return os;
	}

};

	/*friend ostream& operator<< (ostream& os, TPolinom& TP) {

	}*/


